package com.example.tecori;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class resistencias extends AppCompatActivity {

    Button regresarmenuprincipal;
    Button resistenciaenserie;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resistencias);
        Button regresarmenuprincipal = (Button) findViewById(R.id.regresarmenuprincipal);

        regresarmenuprincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent packageContext;
                Intent i = new Intent(resistencias.this, menu.class);
                startActivity(i);

            }
        });

        @SuppressLint({"MissingInflatedId", "LocalSuppress"})
        Button resistenciaenserie = (Button) findViewById(R.id.resistenciaenserie);

        resistenciaenserie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent packageContext;
                Intent i = new Intent( resistencias.this, resistenciaserie.class );
            }
        });


    }


    }
